package au.edu.scu.app;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.regions.Region;

import software.amazon.awssdk.services.s3.model.GetObjectRequest; // read object
import software.amazon.awssdk.services.s3.model.GetObjectResponse; // read object
import java.nio.file.Path;
import java.nio.file.FileSystems;
import java.io.IOException;

import software.amazon.awssdk.services.s3.model.PutObjectRequest; // create object
import software.amazon.awssdk.services.s3.model.PutObjectResponse; // create object
import software.amazon.awssdk.core.sync.RequestBody;
import java.nio.ByteBuffer;




import software.amazon.awssdk.services.s3.model.NoSuchKeyException;



public class App 
{
    private S3Client s3;
    private Region region;
    private String bucket = "rkaur70-a1-s3bucket //bucket name

    public static void main( String[] args )
    {
        App app = new App();
        app.createBucketObject(); // call to create bucket function
        app.readBucketObject(); // call to read bucket function
        
    }
    public App(){
        region = Region.US_EAST_1;

       s3 = S3Client.builder().region(region).build();
    }
    
public void createBucketObject() {
    
    String text = "[{\"name\": \"A\", \"age\": 25, \"city\": \"Gold Coast\"}, {\"name\": \"B\", \"age\": 56, \"city\": \"Brisbane\"}, {\"name\": \"D\", \"age\": 12, \"city\": \"Melbourne\"}, {\"name\": \"Z\", \"age\": 19, \"city\": \"Sydney\"}]"; // content for new object

    try {
                s3 = S3Client.builder().region(region).build();
                
                byte bytes[] = text.getBytes();
                ByteBuffer data = ByteBuffer.wrap(bytes); //wrap create buffer object 
                 String key = "Ass1.json"; // new object name
               s3.putObject(PutObjectRequest.builder().bucket(bucket).key(key).build(), RequestBody.fromByteBuffer(data)); // store object into bucket
              
    }
  catch(Exception exp){
    //      System.out.println("Error: "+ exp.getMessage());
    
  }

}
public void readBucketObject(){
   
    try {

              Path path = FileSystems.getDefault().getPath("A1.txt");// path object to define the content of Ass1.json
              GetObjectRequest req = GetObjectRequest.builder().bucket(bucket).key("Ass1.json").build(); // specified object name and bucket 
              GetObjectResponse resp = s3.getObject(req, path // fuction to copy Ass1.json to A1.text
        
    }
    catch(Exception exp){

        
    }

  
}

}




