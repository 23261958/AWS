package au.edu.scu.app;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.regions.Region;

import software.amazon.awssdk.services.s3.model.PutObjectRequest; // create object
import software.amazon.awssdk.services.s3.model.PutObjectResponse; // create object
import software.amazon.awssdk.core.sync.RequestBody;
import java.nio.file.Path;
import java.nio.file.FileSystems;
import java.io.IOException;
import java.nio.ByteBuffer;

import software.amazon.awssdk.services.s3.model.NoSuchKeyException;


public class App 
{
    private S3Client s3;
    private Region region;
    private String bucket = "rkaur70testerapp"; //bucket name

    public static void main( String[] args )
    {
        App app = new App();
        app.createBucketObject(); // call to create bucket function
       
        
    }
    public App(){
        region = Region.US_EAST_1;

       s3 = S3Client.builder().region(region).build();
    }
    
public void createBucketObject() {
    
    String text = "[{\"Id\": 1, \"Model\": \"Camery\", \"Make\": \"Toyota\", \"Year\": 2020, \"Colour\": \"Red\"}, {\"Id\": 2, \"Model\": \"Pulsar\", \"Make\": \"Nissan\", \"Year\": 2021, \"Colour\": \"Black\"}, {\"Id\": 3, \"Model\": \"CRV\", \"Make\": \"Honda\", \"Year\": 2019, \"Colour\": \"White\"} ]"; // content for new object

    try {
                s3 = S3Client.builder().region(region).build();
                
                byte bytes[] = text.getBytes();
                ByteBuffer data = ByteBuffer.wrap(bytes); //wrap create buffer object 
                 String key = "car.json"; // new object name
               s3.putObject(PutObjectRequest.builder().bucket(bucket).key(key).build(), RequestBody.fromByteBuffer(data)); // store object into bucket
              
    }
     catch(Exception exp){
         // System.out.println("Error: "+ exp.awsErrorDetails().errorMessage());
    
  }

    }
}
