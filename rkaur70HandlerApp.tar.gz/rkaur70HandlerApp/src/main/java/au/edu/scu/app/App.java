package au.edu.scu.app;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
// 
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome; //insert value in  dynamodb table


import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.event.S3EventNotification.S3EventNotificationRecord;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;

import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.commons.io.IOUtils;
/**
 * Hello world!
 *
 */
public class App 
{
  
  
    public static void main( String[] args )
    {

    }
    
    
    public String rkaur70Handler(S3Event event, Context context){ // new handler function with two parameters 
        AmazonS3Client s3 = new AmazonS3Client(new DefaultAWSCredentialsProviderChain());//Instantiating the AmazonS3  class
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withRegion(Regions.US_EAST_1).build();//Instantiating the AmazonDynamoDB class
       DynamoDB dynamoDB = new DynamoDB(client);
        Table table = dynamoDB.getTable("Car"); // creating instance of the table class to represent Car table
        String bucket = "";
        String key = "";
        
        for(S3EventNotificationRecord record : event.getRecords()) { //S3EventNotificationRecord  extracts all the records from the S3 event.
            // getBucket() and getKey() methods are  used to extract the information about the bucket and the corresponding key.
             key = record.getS3().getObject().getKey();
             bucket = record.getS3().getBucket().getName();
            break;
        }
        
        try {
             GetObjectRequest request = new GetObjectRequest(bucket, key);
             S3Object object = s3.getObject(request);
            InputStream is = object.getObjectContent();
            
             String content = IOUtils.toString(is, "UTF-8");

        }
        catch (Exception exp){
            
        }
        
         JSONArray array = new JSONArray(); // new json array
        for (int i = 0; i < array.length(); ++i)
         {
            JSONObject object = array.getJSONObject(i); // retrieved JSONobject
           // retrieve value for each key 
            String Make = object.getString("Make");
            int id = object.getInt("Id");
            int year = object.getInt("Year");
            String Model = object.getString("Model");
            String Colour = object.getString("Colour");
            
         }
         // insert three different values to dynamodb table        
        Item itema = new Item().withPrimaryKey("Id", 1)
                    .withString("Make", "Toyota")
                     .withString("Model", "Camery")
                     .withString("Colour", "red")
                     .withNumber("Year", 2020);
                     PutItemOutcome outcomea = table.putItem(itema);
                     
        Item itemb = new Item().withPrimaryKey("Id", 2)
                    .withString("Make", "Nissan")
                     .withString("Model", "Pulsar")
                     .withString("Colour", "Black")
                     .withNumber("Year", 2021);
                     PutItemOutcome outcomeb = table.putItem(itemb);
                     
         Item itemc = new Item().withPrimaryKey("Id", 3)
                    .withString("Make", "Honda")
                     .withString("Model", "CRV")
                     .withString("Colour", "White")
                     .withNumber("Year", 2019);
                     PutItemOutcome outcomec = table.putItem(itemc);             
      return null;  //return statement 
    }
    
   
    
  }
  







