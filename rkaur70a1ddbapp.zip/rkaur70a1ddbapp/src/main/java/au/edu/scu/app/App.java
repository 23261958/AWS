package au.edu.scu.app;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.AttributeAction;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;//read item
import software.amazon.awssdk.services.dynamodb.model.PutItemRequest; //create item 

import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;


 import java.util.HashMap;
  import java.util.Map;
  import java.util.Set;
 import java.io.IOException;

public class App 
{
  private String table = "Car"; // declare table car
  private DynamoDbClient ddb; //declare  object

  public static void main( String[] args )
  {
    //select * from Car where ID = 1
     App app = new App();
     
     //app.insertItem(); //create/insert the items
       app.readItem(); // read the items
  }
   
   public App() {
    ddb = DynamoDbClient.create(); // dynamoDB client object
   }
   
   public void insertItem() {
    
    // creating new items for table Car
    String[] id = {"1","2" , "3", "4", "5" ,"6", "7","8", "9", "10"};
    String[] colour = {"Pink","Red", "White", "Black", "White", "Brown", "Yellow", "Blue", "Red" ,"Green"};
    String [] make = {"Jeep","Audi","Maruti" ,"Honda", "Nissan","Toyota", "Honda", "Ford", "Dodge","Jeep"};
    String[] model = {"Compass","A3", "Swift","Accord","Armada","Avalon","Mazda","Bronco","Charger","Compass"};
    String[] year = {"2021", "2020", "2019","2021","2021","2020","2021","2021","2021","2021" };
   
    HashMap<String, AttributeValue> write_key; 
    PutItemRequest req;
    
    for (int i = 0; i<id.length; i++) {
    write_key = new HashMap<>();
    // key build for get operation
    write_key.put("Id", AttributeValue.builder().n(id[i]).build());
    write_key.put("Colour", AttributeValue.builder().s(colour[i]).build());
    write_key.put("Make", AttributeValue.builder().s(make[i]).build());
     write_key.put("Model", AttributeValue.builder().s(model[i]).build());
     write_key.put("Year", AttributeValue.builder().n(year[i]).build());

     try {
     req = PutItemRequest.builder().tableName(table).item(write_key).build();// create put request object
      ddb.putItem(req);
     
   }
   catch(Exception exp){
        System.out.println(exp);
       }
    }
    
   }
   
   public void readItem(){
   String[] id = {"1","2" , "3", "4", "5" ,"6", "7","8", "9", "10"}; //string id to read

    HashMap<String, AttributeValue> read_key; // read key for operation
    Map<String, AttributeValue> items;
    GetItemRequest req;

   for (int i = 0; i<id.length; i++) {
    read_key = new HashMap<>();

    read_key.put("Id", AttributeValue.builder().n(id[i]).build()); // call n method specify numeric attributes
    req = GetItemRequest.builder().key(read_key).tableName(table).build();
 
 
 
     try {
       items =ddb.getItem(req).item();
       Set<String> keys = items.keySet();// print content of returned item
       for(String key: keys) {
       System.out.println(items.get(key)); 
    }
     }
    catch(Exception exp){
       
       }
     
   }
   }
     
  } 



 

   
   



